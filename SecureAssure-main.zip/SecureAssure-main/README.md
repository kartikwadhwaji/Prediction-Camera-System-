# SecureAssure
https://drive.google.com/file/d/1Z2qPDZATIT6ZCU1KjQ4qVkEmvCm6LCba/view?usp=sharing
drive link to secure assure backend and frontend zip file . It can be accessed by anyone feel free to use 
